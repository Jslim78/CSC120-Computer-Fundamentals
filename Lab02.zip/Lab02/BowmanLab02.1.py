#Need a number from the user_name

ab = input("Enter number:")
print(ab)

#modulus operator practice
leftover = int(ab) % 2
print("leftover= " + str(leftover))


#If then statement
if int(ab) >= 0:
    print("Positive number")
else:
    print("Negative number")
